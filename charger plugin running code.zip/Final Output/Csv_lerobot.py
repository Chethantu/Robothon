import os
import json
import pandas as pd
import numpy as np
from pathlib import Path
import glob

# --- CONFIG ---
CSV_FOLDER = "episodes"  # Folder containing your 10 CSV files
ROOT = Path("so101_multi_episode_dataset")
FPS = 30

def multi_build():
    # 1. Setup Folders
    (ROOT / "data/chunk-000").mkdir(parents=True, exist_ok=True)
    (ROOT / "meta").mkdir(parents=True, exist_ok=True)

    csv_files = sorted(glob.glob(f"{CSV_FOLDER}/*.csv"))
    print(f" Found {len(csv_files)} episodes. Starting conversion...")

    all_obs = []
    all_acts = []
    episode_list = []

    # 2. Process each CSV as an episode
    for idx, csv_path in enumerate(csv_files):
        df_csv = pd.read_csv(csv_path)
        
        # Extract observations and actions (assumes columns are obs_joint_0... and act_joint_0...)
        obs_cols = [f'obs_joint_{i}' for i in range(6)]
        act_cols = [f'act_joint_{i}' for i in range(6)]
        
        obs_data = df_csv[obs_cols].values.astype(np.float32)
        act_data = df_csv[act_cols].values.astype(np.float32)
        
        # Track for global stats
        all_obs.append(obs_data)
        all_acts.append(act_data)

        # Create Parquet for this specific episode
        n_frames = len(df_csv)
        df_parquet = pd.DataFrame({
            "observation.state": [list(x) for x in obs_data],
            "action": [list(x) for x in act_data],
            "episode_index": idx,
            "frame_index": np.arange(n_frames),
            "timestamp": np.arange(n_frames) / FPS,
            "next.done": [False] * (n_frames - 1) + [True]
        })
        
        parquet_name = f"episode_{idx:06d}.parquet"
        df_parquet.to_parquet(ROOT / "data/chunk-000" / parquet_name)
        
        # Add to episodes metadata
        episode_list.append({"episode_index": idx, "tasks": "plug in charger"})
        print(f" Converted {csv_path} -> {parquet_name}")

    # 3. Calculate GLOBAL Stats (Crucial for AI normalization)
    combined_obs = np.vstack(all_obs)
    combined_acts = np.vstack(all_acts)

    stats = {
        "observation.state": {
            "min": combined_obs.min(axis=0).tolist(), 
            "max": combined_obs.max(axis=0).tolist(),
            "mean": combined_obs.mean(axis=0).tolist(),
            "std": combined_obs.std(axis=0).tolist()
        },
        "action": {
            "min": combined_acts.min(axis=0).tolist(), 
            "max": combined_acts.max(axis=0).tolist(),
            "mean": combined_acts.mean(axis=0).tolist(),
            "std": combined_acts.std(axis=0).tolist()
        }
    }
    with open(ROOT / "meta/stats.json", "w") as f:
        json.dump(stats, f, indent=4)

    # 4. Final Metadata files
    info = {
        "codebase_version": "v2.1",
        "robot_type": "so101",
        "fps": FPS,
        "features": {
            "observation.state": {"dtype": "float32", "shape": [6]},
            "action": {"dtype": "float32", "shape": [6]}
        }
    }
    with open(ROOT / "meta/info.json", "w") as f:
        json.dump(info, f, indent=4)

    with open(ROOT / "meta/episodes.jsonl", "w") as f:
        for ep in episode_list:
            f.write(json.dumps(ep) + "\n")

    print(f"\n🎉 DONE! Created dataset with {len(csv_files)} episodes.")
    print(f"📍 Location: {ROOT.absolute()}")

if __name__ == "__main__":
    multi_build()
