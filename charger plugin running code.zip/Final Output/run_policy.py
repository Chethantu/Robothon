#!/usr/bin/env python3

import torch
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class PolicyRunner(Node):
    def __init__(self):
        super().__init__('policy_runner')

        # ===== LOAD MODEL =====
        self.model = torch.nn.Sequential(
            torch.nn.Linear(6, 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128, 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128, 6)
        )

        self.model.load_state_dict(torch.load("policy.pth"))
        self.model.eval()

        # ===== STATE STORAGE =====
        self.current_state = None

        # ===== PUB/SUB =====
        self.pub = self.create_publisher(JointState, '/joint_commands', 10)

        self.sub = self.create_subscription(
            JointState,
            '/joint_states',
            self.state_callback,
            10
        )

        # ===== TIMER (SAFE) =====
        self.timer = self.create_timer(0.05, self.run_policy)

        self.get_logger().info("🚀 Policy Runner Started (Safe Mode)")

    def state_callback(self, msg):
        self.current_state = np.array(msg.position, dtype=np.float32)

    def run_policy(self):
        if self.current_state is None:
            return

        try:
            state_tensor = torch.tensor(self.current_state)

            with torch.no_grad():
                action = self.model(state_tensor).numpy()

            cmd = JointState()
            cmd.name = [
                'shoulder_pan',
                'shoulder_lift',
                'elbow_flex',
                'wrist_flex',
                'wrist_roll',
                'gripper'
            ]
            cmd.position = action.tolist()

            self.pub.publish(cmd)

        except Exception as e:
            self.get_logger().error(f"Error: {e}")


def main():
    rclpy.init()
    node = PolicyRunner()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
