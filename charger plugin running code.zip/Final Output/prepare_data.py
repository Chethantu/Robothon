import numpy as np

# ===== LOAD YOUR DEMO FILE =====
data = np.load("dataset/demo_20260414-194806.npy", allow_pickle=True)

print("Loaded data type:", type(data))

# ===== HANDLE DIFFERENT FORMATS =====
if isinstance(data, np.ndarray):

    # Case 1: Normal array (N, 6)
    if len(data.shape) == 2:
        print("Detected shape:", data.shape)

        states = data[:-1]
        actions = data[1:]

    # Case 2: Object array (list-like)
    elif data.dtype == object:
        print("Detected object array")

        data = np.array(list(data))
        states = data[:-1]
        actions = data[1:]

    else:
        raise ValueError("Unsupported numpy format")

else:
    raise ValueError("Unknown data format")

# ===== SAVE OUTPUT =====
np.save("states.npy", states)
np.save("actions.npy", actions)

print("\n✅ Conversion complete!")
print("States shape:", states.shape)
print("Actions shape:", actions.shape)
print("\nSaved files:")
print(" - states.npy")
print(" - actions.npy")
