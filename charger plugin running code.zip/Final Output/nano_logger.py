import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import numpy as np
import os
import time

class So101DataLogger(Node):
    def __init__(self):
        super().__init__('so101_data_logger')
        
        # 1. Subscribe to the joint states published by Gazebo
        self.subscription = self.create_subscription(
            JointState,
            '/joint_states',
            self.listener_callback,
            10)
        
        # 2. Setup the saving path
        self.dataset_dir = './dataset'
        if not os.path.exists(self.dataset_dir):
            os.makedirs(self.dataset_dir)
            self.get_logger().info(f'Created directory: {self.dataset_dir}')
            
        self.joint_data_buffer = []
        self.get_logger().info('--- SO-101 Logger Active ---')
        self.get_logger().info('Waiting for movement in Gazebo/RViz...')

    def listener_callback(self, msg):
        # We extract the position of each joint
        # msg.position usually contains 6 values for the SO-101
        current_positions = list(msg.position)
        
        # We only record if the data isn't empty (Gazebo sometimes sends empty first frames)
        if current_positions:
            self.joint_data_buffer.append(current_positions)
            
            # Print status every 50 frames so your terminal isn't too messy
            if len(self.joint_data_buffer) % 50 == 0:
                self.get_logger().info(f'Captured {len(self.joint_data_buffer)} data points...')

    def save_data(self):
        if len(self.joint_data_buffer) > 0:
            # Generate a unique filename using the current timestamp
            timestamp = time.strftime("%Y%m%d-%H%M%S")
            filename = os.path.join(self.dataset_dir, f'demo_{timestamp}.npy')
            
            # Convert list to a NumPy array and save
            np.save(filename, np.array(self.joint_data_buffer))
            self.get_logger().info(f'✅ DATA SAVED: {filename}')
            self.get_logger().info(f'Total frames recorded: {len(self.joint_data_buffer)}')
        else:
            self.get_logger().warn('No data was captured. Is Gazebo running?')

def main(args=None):
    rclpy.init(args=args)
    node = So101DataLogger()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        # This triggers when you press Ctrl+C
        node.get_logger().info('Stopping logger...')
        node.save_data()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()