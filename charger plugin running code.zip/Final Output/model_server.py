import torch
import numpy as np
import socket
import pickle

# Load model
model = torch.nn.Sequential(
    torch.nn.Linear(6, 128),
    torch.nn.ReLU(),
    torch.nn.Linear(128, 128),
    torch.nn.ReLU(),
    torch.nn.Linear(128, 6)
)

model.load_state_dict(torch.load("policy.pth"))
model.eval()

# Socket server
HOST = '127.0.0.1'
PORT = 9999

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(1)

print("🔥 Model server running...")

conn, addr = server.accept()

while True:
    data = conn.recv(1024)
    if not data:
        break

    state = pickle.loads(data)

    with torch.no_grad():
        action = model(torch.tensor(state)).numpy()

    conn.send(pickle.dumps(action))
