import os
import json
import numpy as np
import pandas as pd
from pathlib import Path

# --- CONFIG ---
NPY_PATH = "demo_20260414-194806.npy" # Make sure this is in the same folder
ROOT = Path("so101_charger_dataset")
FPS = 30

def manual_build():
    # 1. Load your data
    data = np.load(NPY_PATH).astype(np.float32)
    n_frames = len(data) - 1
    
    # Create folders
    (ROOT / "data/chunk-000").mkdir(parents=True, exist_ok=True)
    (ROOT / "meta").mkdir(parents=True, exist_ok=True)

    # 2. Create the Parquet file (The actual data)
    df = pd.DataFrame({
        "observation.state": [list(x) for x in data[:-1]],
        "action": [list(x) for x in data[1:]],
        "episode_index": 0,
        "frame_index": np.arange(n_frames),
        "timestamp": np.arange(n_frames) / FPS,
        "next.done": [False] * (n_frames - 1) + [True]
    })
    df.to_parquet(ROOT / "data/chunk-000/episode_000000.parquet")

    # 3. Create info.json
    info = {
        "codebase_version": "v2.1",
        "robot_type": "so101",
        "fps": FPS,
        "features": {
            "observation.state": {"dtype": "float32", "shape": [6]},
            "action": {"dtype": "float32", "shape": [6]}
        }
    }
    with open(ROOT / "meta/info.json", "w") as f:
        json.dump(info, f, indent=4)

    # 4. Create stats.json (Calculates min/max so the AI can learn)
    stats = {
        "observation.state": {
            "min": data.min(axis=0).tolist(), 
            "max": data.max(axis=0).tolist(),
            "mean": data.mean(axis=0).tolist(),
            "std": data.std(axis=0).tolist()
        },
        "action": {
            "min": data.min(axis=0).tolist(), 
            "max": data.max(axis=0).tolist(),
            "mean": data.mean(axis=0).tolist(),
            "std": data.std(axis=0).tolist()
        }
    }
    with open(ROOT / "meta/stats.json", "w") as f:
        json.dump(stats, f, indent=4)

    # 5. Create episodes.jsonl
    with open(ROOT / "meta/episodes.jsonl", "w") as f:
        f.write(json.dumps({"episode_index": 0, "tasks": "plug in charger"}) + "\n")

    print(f" DONE! Your dataset is ready in the folder: {ROOT.absolute()}")

if __name__ == "__main__":
    manual_build()
