import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

print("Loading dataset...")

states = np.load("states.npy")
actions = np.load("actions.npy")

print("States shape:", states.shape)
print("Actions shape:", actions.shape)

X = torch.tensor(states, dtype=torch.float32)
Y = torch.tensor(actions, dtype=torch.float32)

# Model
model = nn.Sequential(
    nn.Linear(6, 128),
    nn.ReLU(),
    nn.Linear(128, 128),
    nn.ReLU(),
    nn.Linear(128, 6)
)

optimizer = optim.Adam(model.parameters(), lr=1e-3)
loss_fn = nn.MSELoss()

print("Training started...")

for epoch in range(100):
    pred = model(X)
    loss = loss_fn(pred, Y)

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    if epoch % 10 == 0:
        print(f"Epoch {epoch}, Loss: {loss.item()}")

torch.save(model.state_dict(), "policy.pth")

print("\n✅ Training done! Model saved as policy.pth")
